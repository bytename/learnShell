#!/usr/bin/env python
#encoding:utf8
import sys
import readline
import os
readline.parse_and_bind('tab:complete')
histfile = os.path.join(os.environ['HOME'],'.pythonhistory')
File = file('ipconfig')
print '========welcome to linux==============='
newline = {}
num = 0
while True:
        for line in File.readlines():
            num +=1
            newline[num] = line.strip()
        break
def ip():    
    for key,value in newline.items():
        print "%s.%s" %(key,value)       
while True:
    try:
            ip()
            options = int(raw_input("Please choise your num:"))
    except KeyboardInterrupt:
            continue
    except ValueError:
            continue
    try:
            if options in newline.keys():
                name = raw_input("username:")
                if not len(name):
                    continue
                cmd = "ssh  -p 10096 %s@%s" %(name,newline[options])
                os.system(cmd)
    except KeyboardInterrupt:
            continue

